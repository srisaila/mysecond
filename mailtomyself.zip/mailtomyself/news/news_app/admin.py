from django.contrib import admin

# Register your models here.
from .models import NewsUser

class NewsAdmin(admin.ModelAdmin):
    list_display = ('email', 'date_added',)

admin.site.register(NewsUser, NewsAdmin)