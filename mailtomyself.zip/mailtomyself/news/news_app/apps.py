from django.apps import AppConfig


class NewsAppConfig(AppConfig):
    name = 'news_app'
