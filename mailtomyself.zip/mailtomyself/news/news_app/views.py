from django.shortcuts import render
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings

from .models import NewsUser
from .forms import NewsUserSignupForm

def home(request):
    template = "home.html"
    context = {}
    return render(request, template, context)


def news_signup(request):
    form = NewsUserSignupForm(request.POST or None)

    if form.is_valid():
        instance = form.save(commit=False)
        if NewsUser.objects.filter(email=instance.email).exists():
            messages.warning(request,            
                            "Your email already exists in our database.",
                            "alert alert-warning alert-dismissible")
        else:
            instance.save()
            messages.success(request,
                            'Your email has been submitted to the database.',
                            "alert alert-success alert-dismissible")            
            subject = "Thank you for joining News"
            from_email = settings.EMAIL_HOST_USER
            to_email = [instance.email]
            signup_message = """
            Welcome to News!
            
            If you would like to unsubscribe, visit http://127.0.0.1:8000/news/unsubscribe/
            """
            send_mail(subject=subject, 
                    from_email=from_email, 
                    recipient_list=to_email, 
                    message=signup_message,
                    fail_silently=False)
    
    context = {
        'form': form,
    }

    template = "news/sign_up.html"

    return render(request, template, context)

def news_unsubscribe(request):
    form = NewsUserSignupForm(request.POST or None)

    if form.is_valid():
        instance = form.save(commit=False)
        if NewsUser.objects.filter(email=instance.email).exists():
            NewsUser.objects.filter(email=instance.email).delete()
            messages.success(request,
                            'You email has been removed',
                            "alert alert-success alert-dismissible")
            subject = "You have been unsubscribed"
            from_email = settings.EMAIL_HOST_USER
            to_email = [instance.email]
            unsubscribe_message = """
            Sorry to see you go. Let us know if there is an issue with our service.
            """
            send_mail(subject=subject, 
                    from_email=from_email, 
                    recipient_list=to_email, 
                    message=unsubscribe_message,
                    fail_silently=False)

        else:
            messages.warning(request,            
                            "Your email is not in the database.",
                            "alert alert-warning alert-dismissible")            
    
    context = {
        'form': form,
    }

    template = "news/unsubscribe.html"

    return render(request, template, context)
