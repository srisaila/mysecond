from django.urls import path

from .views import news_signup, news_unsubscribe

urlpatterns = [
    path('sign_up/', news_signup, name="news_signup"),
    path('unsubscribe/', news_unsubscribe, name="news_unsubscribe"),
]